<?php
class shk_order extends xPDOSimpleObject {}