<?php
require_once (dirname(dirname(__FILE__)) . '/shk_order.class.php');
class shk_order_mysql extends shk_order {}