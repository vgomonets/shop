<?php
class shk_purchases extends xPDOSimpleObject {}