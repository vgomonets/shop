<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'shk_order',
    1 => 'shk_config',
    2 => 'shk_purchases',
  ),
);