<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ec1c678acc9c59c988824307adaf0629',
      'native_key' => 'core',
      'filename' => 'modNamespace/e9d455fa4b6e0a52b65e8d9954ec4e7e.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'c70b9e58ecf9770218f6b09b548affb0',
      'native_key' => 1,
      'filename' => 'modWorkspace/a0628e6c3225c90de485b245cd026670.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '4bd36c6203daffa8576408d7cfe20b1f',
      'native_key' => 1,
      'filename' => 'modTransportProvider/7604dfb357712320a822de26c3b1cc9a.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '934f307bc92093f5ec35072bca0f1f2a',
      'native_key' => 'topnav',
      'filename' => 'modMenu/ac628df1a0286389772348f66a0d5aaf.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '423e32dd56bed424d50094cd074c929f',
      'native_key' => 'usernav',
      'filename' => 'modMenu/b3f560d044dc8c3b066a11d3723e7323.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c4e1885722d6829cfea35010962150ed',
      'native_key' => 1,
      'filename' => 'modContentType/e08f3d4b47f05cb07e0c7ed18c1459fd.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'abe0d91e0fad37bc66c699be3121b73f',
      'native_key' => 2,
      'filename' => 'modContentType/29ea45c1f1d16224e51d599b34c95fcc.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c468df2ef8c5dde198f2c857ac866ae9',
      'native_key' => 3,
      'filename' => 'modContentType/e030a56b24b574d3a6365f2d0b982420.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '2bd4d91818b473483c122b55614abc89',
      'native_key' => 4,
      'filename' => 'modContentType/4c08e3435454243c880f0bb0d6786620.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '7a2b8b9afca8a6e1a304ca29cdc7188b',
      'native_key' => 5,
      'filename' => 'modContentType/7fbb5d7d62d2ec3de4aebec88c7a6093.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '6dacdc3e74802bea625c69f151c0a309',
      'native_key' => 6,
      'filename' => 'modContentType/49c823e5a21917f7bccb2b36d9e86978.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '37342e69d31b038ab9db151f08252926',
      'native_key' => 7,
      'filename' => 'modContentType/1a1775315330148e286654c7a1cc7a3e.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '2e2a0b8f04fb1a0892ab54806df44649',
      'native_key' => 8,
      'filename' => 'modContentType/6754f60420a1fd285beced9368dd42c1.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c31bc87d8e17692e564031c968faf7c4',
      'native_key' => NULL,
      'filename' => 'modClassMap/f86851cb10956b7278ed6f9a7f0ff4c3.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3b69592dc77c438fb98b74c1ef3eaf8e',
      'native_key' => NULL,
      'filename' => 'modClassMap/cecae206693b99c6c223c862fb3fc4a4.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5bf7ea35ffe60d0267dc9d9c15c0ae23',
      'native_key' => NULL,
      'filename' => 'modClassMap/34e06af692a4b9860935d2a34a9b18c1.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '6807b745d2e7442f1cdf2c8af89bd9e9',
      'native_key' => NULL,
      'filename' => 'modClassMap/a46b25d7e5624f7b201df0efd9d74cae.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '004a61e92de7b3ec89e5b4cdaa918daa',
      'native_key' => NULL,
      'filename' => 'modClassMap/22ab7cd2a9684a52adb76326e25d850e.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '6cb1362d2a38b0eed6c0dfeeb963e079',
      'native_key' => NULL,
      'filename' => 'modClassMap/0d05c9124d9e88ce2bb821124559920e.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ea5fdc025a4e9113b23f139dca46a8ce',
      'native_key' => NULL,
      'filename' => 'modClassMap/c6d0551e773ed3654663dbc7e92cd4ea.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '066c7e156723f0f70d4ba9219ed1af4a',
      'native_key' => NULL,
      'filename' => 'modClassMap/2867904d0d0938f0b21e7f3615957af7.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7e6b4df9a6876ccdd8d34d5b1e6925a5',
      'native_key' => NULL,
      'filename' => 'modClassMap/0ed77eef9940d172100d34cb710a52d7.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53c83d1a7b8b50f64bf1a7e1def996eb',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/9ab8c0d37476ef69f6e5e9971b526abb.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d7c5a77546505190fd209d19f1f7973',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/0c1852202e3c2756cc6589034cf36efd.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e8cf20c49a7f6f6b7b0cf15d603f9a5',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/ab9b8278e57d74cfd4dc202619dd096e.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72d157be44df45a7963aa501f56be099',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/aad6feba7df6f8f3da816d10c50a37cf.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8dfd0fcc581a20d261bcd9e159d417a',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/5315023a7884631b696303324962a2bc.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e180bf00886d81fc6fe2d314d41b553',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/9c42fd6793c99a1c78c91a6c8e0d8897.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cc97aa0d914da56f5d0743ef29d0f45b',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/5e4d77ec55d5291b96c5f77a193501d4.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b5a298997f390472c07c3ca34df31567',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/ccd7af33f2a456de70e4b00cbacfa3d6.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3abdd12c0a90e95f0851a3c68fb5debf',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/a521d69582577705ad85de72c472e7aa.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af57597c0875acef062cf2cf705ed904',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/eaa9f22f056729be8fda8e2108d20dcf.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8912ea327dcb07c852ae5454a90e0d1',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/9283d8b731ab90dc4e263d3dd67e4b01.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66a31b936d4e2ce54727ea5f564e23f9',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/f93337c0e003c97c50f14dc0a7199185.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0fa94297372d5e22be6ce38353bf56ab',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/f34c0f7ba26b952c89fa2efca970d66b.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75ab4d1fc38401a931b3e5efc58c4c7f',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/fbeb02287ab296f917ba890cea5b1eb1.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd33fe7a68e989c4a77bacd5f0d4dac22',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/ccac0398ca218a07da1c0e9132e142c6.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '425c903bb70d90fc8bebcf68da11ad65',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/31ac9909a344c4e76fcf0ba498a3e578.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e05095a2775ed5185fc69c93946813b',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/81b45c33d08a472a4d255af480cf170a.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac0443d1f5cf5dcbcd8fb73b70b86b50',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/5bd3d1005367d06a6e5837a29f4d2162.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50fa682518fe1b158c90a8630373dfcf',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/387fa6e9c027d9bf09f05bc557794819.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ecd697542f078d9cef962f2410d5dd6',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/348146956d5460a2fde2b1acf29f7a6c.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c23bf73161a478e18440b20f01b629fb',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/cd97ef6f1adf8e025051b3df73384675.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4bb5f954f3545d733dd8195c78a3222c',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/ae6ee5c06fdedef0e5eb7fabdf25d7f2.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ecfd1d12c1a5bcf79b8522cf6b40f4c',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/7904b6a18aa1e09865398d598f1fd57b.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '664f32eefaf68d0746135d26eacd4440',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/49aa0934b288c2be1f708c1a3f18726d.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '221797537c587afb7f874a567a76ee5b',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/24025a552b6f450912cbbc1df2d96c7f.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb6d22957af74ca5f0d70f1f564a9234',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/f52c16006b3b128d2c354abecf7e5bcc.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '628870132f8c96283d89e832c6ac31dc',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/a2163672044ff7cba4d1f8f4a2349884.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68334eb9c0a67367a4a864a1415b0867',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/00fc8da20d45b1e65a62cbd02b88a701.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d6c1b3d9bdf0adceb66e8e07d114dd3',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/cc3dca18c4199ccbc6665b2861ef8a3a.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c272d5766f42479d56a3e3bc3f4e6c98',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/32f4c1d4a808228b7f2a6266712e9893.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83402aa919d010e9192b64ba0b1abc84',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/7b58162542f9519035c14cdcd038593b.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef860bf0b7b837cf5645443053f95315',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/646807c23c776f8d3fa243d257b95ddf.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b79259451a3fabce0d37df2d0e2dc7fe',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/7e10d7fea7e262da67f0bd088de8e21a.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e09ec55c316a345c348bd285c6183e5',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/8df2ef73f334b9e019bb5b3c659733b7.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f3419bff771b49155d1c23159f8d471',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/9bf0cd96230ccda6735992f1de9f1ef9.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d1193c0794a93a84efc585aba176efa',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/f9b7d630bf38bc86260acb26c290358a.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f8c45b1cbbe1eb51cedaaa3add7fc56',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/c7925373dc39cb8290ad79e09b6fd23f.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c590de2a3ac05f02b15e0db2f1608bf',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/6ef4245b2eb5313c1f277966db2a9da3.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc4dad45e2d760b69b9cb0302c60d35a',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/76f1c11b1f99c91f08a3293276fb2d3d.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b1444c6bcdfd2e70250b6598f1f5402',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/f435fe9c8da4c4a0ecc7e8625b16a348.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b731b9ce22bb7c29286c551714b1535',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/bbc9b877a8277a0b2104873b2b7d4012.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98409a358b1ee073a766da405f795b56',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/2ce73e2f20d349f6842f54a9b35b420a.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b757c4451a5d2b8dbf1f977de0006f44',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/6673e57c0a9d1786789983a441e45922.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab909f1c09e7d50e6fef907c52388275',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/6f22c1d9f44209df3cd10ed335c1a345.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '116904ad2a98988c24a2e0957c116129',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/2459c59563716c70a266cae6ec65133b.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e382c9d0d0b887fd1a64543196e1056d',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/e0ae9c7949bccc446ec390a7ea421075.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e464a6a78ff006c7c8aa1006bea3839',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/ba5074754c7b5fb5f7130a4a4fd7aaee.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f3d6de1f2790fc0446549d770f9d1f7',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/518cd3c492f1bce042a16643ec9dcbd1.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c26c77b2be6ae74faa7fd8ef1d3c6464',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/e20ac7b772a58aea17aadca682db7b31.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59aa4f150d3b9a49cf82b32751df0fc1',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/77fa24a3743e826cc1fea515860f9d46.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb249c093ecb27414640cac5b931ec6a',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/f4f74d2c1e8687c1b0f1db965b2d1489.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3ab0c58b49fca1de966588c2cdf6186',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/b711e4c5254fdd6eb46a2f145cd6f4ba.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d69f6890d8a6a66716f845a646415c5',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/d11298d0066896b46229f96132fe2eb6.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3886e8c34336e47b27d97619cdc50d5b',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/935dd9549fd217c952e8bb99ac893004.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd4b2bdf8f9c67c566a98ebb8b844c97',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/3337dd56c5e1307db41b331871c0a0c5.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '089f0a842b23ac71031fc12378355259',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/59dfe07c1b3bc72e1b162486d676d555.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a58e86908cf5665f720ff8772e3a7282',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/c18da11cf072546b4b1bb4125ad2237e.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cbf27d87660cef5f8043f2d0feb5b66',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/71b50da6aab10bc28ec61baf10387d93.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f27add7641e433790dafeaec21b97e4',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/03188ce82756664fe60b6a934886b5cc.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1644ea93c215747560c1baa694b3e14d',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/f5a3c5ec468612e18ea3b2d1e7d5ef17.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b0173f11387b45c01f75fd2f6ce7d89',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/50e9351059f561426bfe24ccab4003bc.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e41eb505d1580051949dca2814d3064',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/38c52b4cd0ea4211da6f825429b23941.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '602048c959f4dd83a3a6e920e9021fde',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/1608a586ae8617b9565277dc53df7d01.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '147e63aec65750fb05f593a631fd3576',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/bad02bbbcaaff07dc5772cbee8217d89.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '62f0d32fdb40fc35ca059aa98683daa0',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/fa7dd8c7e2a8db26d10430a7e8f12969.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41c983f122e538a8ae7a5894930bb82d',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/58043e1700f126f36d2bb1878a390509.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0bdd0343317005e81162e521762ed678',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/0dfd6bbd7c214f506036366558f49903.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a0c3ff308af2c913fe86b5bda698cd9',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/644e3df61ff99b79415fe2845f720bd7.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06031517475fc8a6296516ae675188bf',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/f17548deeee798cbc6c3cffa08cc931b.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'faae3c8caa1b803901c1e567426a102d',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/685695247c12b46599ba8880441c6b39.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7eee14208e593e9f0e8674f24df86268',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/7f4a0412bd8ebc87d1323b4b48224540.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d93e0c413aa780f3a4f49e4b9e8b801',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/9a3977c4ee82bcf85110d083d754f8e5.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '24e60d41a477d0a5b1624ff8980caa75',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/75a5d2642f8a1e58451f82a06c891af8.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e7009df2b9137ee04939070b55e3519',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/007f72cf37989458483c0e2380d92ea9.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49e024cf5aa76341991a23a740ce1ba7',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/35c4eaa4e1e1fa0d986d9827d2c0ae45.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e6857f437564f2cc05e50e3bffc6d66d',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/ccfac0bd2489ab206673359cc299b2fd.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af626f83fc05d38043015d75735a75b1',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/eef9821ba2bcab3f41a734a445612934.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10b785a8b1b1546b237cdd72450030c6',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/de274e3d276d0f8c649113fac6cb2104.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6fc7a6d5632e2b19f58ee39c434c814e',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/099a25b2c918392d9a00334f0078346e.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1bdcff09422739f55d961366ab30f5e',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/7e90f71ad465dca033fc04b358937994.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc9fc8d3bf944002b6393ad6eec11ecb',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/a110f63b3265837cacf8da9914cd9598.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0faef2054fa09720566753a6c8f1e147',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/a9e98b3d9f79ab46411df69b7d74cb9d.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd41b101e7a2d6325ca55347927140517',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/036bfb0f8b1813e3d321c3d9ea9c24b0.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9efae43ab49b4836115261f209b28c62',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/9e61aa7f1ad14102775dd6408decd78f.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e19c5bc103862b34304691188adf5ff4',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/9a73747d895ced89e54dd09b8982ee32.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2939b0e9c20ef6679f06c40c15941b0f',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/d2961b066ab1464e347339c04d17835c.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94a3042c2cc18320c25f3707a095ef39',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/06fe219417576e237c47373e6cc8a534.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '518e6744ce35ab36bf5e5811d4618f7c',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/269b5d39b40cde434bc4a30b9fc4315d.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '785ad7b4d62883c7adbab34ac755f25c',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/f647bb154d95298990824e303389398a.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94cf51e9b977bd23b6fca9cc8c27334f',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/3cefb42c5649cdeb41409b3ac6953d6f.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72f489965561b1275d1cd3bab83c1e46',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/8ee5da0a883fb549645c92720531198f.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50ccfc6acaac6a20f7e8380d60365864',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/3a5081d0b8fc3d5ef43863b43e32209a.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a233efd5d10eb61e0e13bca17fa274ff',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/cde28a94503e40a602949d77e1727045.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49965ab2c8bc5422b971d6a04ca4969a',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/a5fabd54f374709e4d4d357641c25a82.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7c72d90553df2872ef0ce5b7fba4b43',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/fb0c07435eb88de4ae461a8b05545a81.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3c7634a8a809e887a42f5b74d8e877a',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/79bd28c5b0fe8feaf71c6cc1e0c23cc3.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2e40ea4ed50d0b3ee40c74bfe55bf01',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/8f7ad02402a829782e7c9b67e5f23dd7.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30150519ffca18521172bd7b506b4e18',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/8f91dcd98505f5352a70474b946f7d27.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9431bfb88bd6a68a9d69a818374021fd',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/916e3f4dd433d61aa4e7f515da26143e.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '826cd52f4ff9626ab32bada6e0212b57',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/5abaab0d18688d4bedd9b52464f67b8f.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd23fc5047c3ca741308b3c6e7bf8dada',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/6333499d48f03365ff53070719aaec58.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99a328626f7247e260d4617ffec51c21',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/59c05660de831d2018de3d922a157e58.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '785b1dd3c4fb13f8f3b0a4e9551a78c7',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/605911880d104150c0db894b1d35f5bd.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20127729d6d1254036512c5552a3a278',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/cacaeb79a363498a02e283c1b50d5094.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95657cc5e696aa106df71f7c68b44855',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/96c9fb801f2d425f2b6659d8c380302d.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3f80222a193f32f1af7d8f88f0c340c',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/5f901689728e7cb293381dd3b9e8e65f.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19c06cb02b9fad693f91176540dde3c5',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/9ee014f9d0d95b0debe8cfec1aa92098.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c0a2e2e98afb5229e5cf0cb17d08519',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/89b44ff9e8b6072b177a7ceb8f3e256a.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80f962cf8f1e65ffffe299a845f032af',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/b1aaf5ef5c11beb5fa2ab9416e6a4170.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09ab0c802ed3fcb0bf353581985afec0',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/a37359656ee48ed87f7b0afaac04e142.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fe0b7d84c0f9e911de25f0e7bd94ffc',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/00e70b593a5c3bb6712bd08dd3b2b55c.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e6401541c86af8d060c10fa11e137bf',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/39e31b297bdf92a8019d4018550c64d7.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aeff7ebd3b7b51d8b57f3791680a7c21',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/a73488d6441454f37e09f35e878824e8.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8e1e778450f67ba507573b48ccad400',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/36d1618e311d715c575c101c29a974a3.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90630fd7e5c5bdf9595060b4c83a386e',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/8f833fd5ddeda1179557c9d5803d6be3.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a88c1a8b025f9994e041fbeeffa06a7',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/2fd888f25477dde144b09fff3eeb1753.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22d4cfe34788efe4dc0943fa866c3191',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/272cc96f815943a4d32c782772f6a1b6.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ec435ec9c4a2869a43eee833889521a',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/0ba2846b5f6c254222de550fbcc7b551.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '704859c30d742c4f734ea2dfd4d75a4d',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/51a52a68d87bc7662ff4959120055f8c.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a71f8cdd5c87aa6121f063fe1236633',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/6ef7be21370a1e70e463e223571226dd.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b8d34bf99739105215f444b764b70c1',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/7075aabc93d9da15e82a4122163a9245.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ce0ab92668e75dd290f5663fff3db9a',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/e2fbc73da6e972a6ab28e917eaa13acb.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '172cfdce7f428ca865bb11cdbd5cbe87',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/e6e4da39d8db949fe07a029de0ce09a3.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0f7b04387257870ba1c1efc84d566bf',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/c38704dba1c55af0463c0357517dc602.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c34f8d2721e647c7ed8c4548a15d404',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/e97cb794c33d001d4f69f40d98844c18.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdf66d7a78c20768d12a7f6a30d702cf',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/8991fb6ac1805f6dcd9195234a98d562.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7454a08d153bc39185dc333aeb2438f',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/ae3319b58960cc877c4ef61455d45d64.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb69bfb69e1656f3e393c87bf831df80',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/2909ba20a164e5b9d713f78ce0f36fe4.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09ead4fa520e332edd0dcad1a9bd70a7',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/eb955c11fa8111f4555484d4370f9d7f.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64615fb3f096e7ae51118762699c722d',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/3cf58bc65590d549b0662d983380d649.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '358770aae9cb971f97265627049d40bf',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/76a64779b3a3cc0b1f34230feaed3273.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88c39e920672c24be2fd3c45bc643acf',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/d1ba87d975fd9b0b35eab0d28da65215.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff551972f63cd5674fd7d9d8b7a0e0a5',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/113681abd5e5e4379917859e4347673c.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4da94cdefe9b2dd93806ad3dc2cc3c2',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/1cf0d57fa289801f75ad2842ccb6f585.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf4b3bd0fbbcdffdc7d264dff9037000',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/3dab8e4b8b243dbd2cd8203c8149111d.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd633e11bef48a0c1a6a6919197c193d7',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/5a23ed72365fb509a3e5aa26cfa615b6.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd356898e2053aeb26d8d6b9e17362b42',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/ea44b5cfe63990eff373a813618f91c8.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '048bcaf72d9e01087033232c7ab0f07c',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/23698776576a7ced58d072be8442bd3f.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2664691ff0e410f5cac26b2bb344b8d1',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/89dc94323b7275f6085f4d69a5a64fe2.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33efcd75347d90d35276f54c1e2b5ca9',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/75ba7e796cbaeaf179b2f37a267da7d8.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9acb887ba76c883bdcfc54a8f937c701',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/be88bb27f2f93882cc1928533914ec7c.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53c34207e1acb59c836d248bd085768c',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/5e8331f18590495cd9c18e8dfe97fac7.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e53647a4be6b101b92918c3214bbb1a2',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/8190d81f8e7a985a24abd0e57dd4033c.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3219cea6b47adcb10110d441aa27abee',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/b632bca7fc1a4dcb2dcc71518c83b416.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96e1bcccb75d349477ea86b7f203c6d3',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/dfc26c0396efbd55505a63fca8001f72.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c55fe985f4cbd38aec3259dbcb4d976e',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/b312d8c704e7f9567a4a3a8680eb72f6.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e133b4c3107bd86ce49f89f4a3e2fbc2',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/e31ee62e640d92b3313d73c113b69e6e.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f082b1a6c8f5127d644799be349a601',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/bd862d5fea9381a8aa20aa0049d0267f.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7119edcdc537da0c90d6241ee386197a',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/03379247a5cdb45fd8ee8a5995010752.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '342910410da4bbcddb416d945adced45',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/f1902919a8225a185a1aea0729d779e6.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3c355d3ccabf77d055b5575c0e96ad6',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/3011349f54c8f935023c92fdb7d607de.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b687697795d182be05724b113e185138',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/ab7e5ad20b9df575c03b0965b88e725d.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02460d73ca530d5b98df3c1f4edfa00f',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/14e5baa77feec68bb63c4b59ce2ea86f.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f85678e1209c2526a5e73f5c183c5e2a',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/ef8d630d5b227f2067b9cf4bb1c1e749.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1cb25fc0e5d2194af4d575a93b28736',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/afb0c06a7b5ae8c46719ad207abb8983.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f8b4ca95d33595b07ea7c439681e111',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/0f6b4640096ca43c04cda3a547df96d2.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38dd45e8d5f9863c9e841d7c40427a49',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/3956af1ac5e936f5da13e542ba738886.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e99b78f2b45555f77e7421ba6874d16',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/2a8df63589071eda502de440501eb272.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'beb151864bc7f3a8abf32612574f056a',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/fda9541680688435be16eb88cf0400a7.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7dcb6d003c609a2a5a8346a07b04346b',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/35069be241ff2744a8997b452f541bea.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e4d5874211d35cfd8f351eee9d9bc6f',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/05b1ddae8c8ee23a81929054e5b4b77d.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '105b4251cb81f6e351bfd516362b57e3',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/9d129f6b72f665cc5d6096937ca56f64.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '570f3021fa00f458161c1171f844b937',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/4fd9a761a55d8a63471d2ad925f7d651.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22c0300c8f2d254df5385e91edc93cc4',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/a302978c5c3e1d00e33846acb33b9e80.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87978bb5509feb53f01c8bd0e1eff52d',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/0d0843662c221c4f645d9a30779810c0.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e3f4aea1beb926410f416e5c8be49d8',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/7d6dd72898018954316b7092dc7cf699.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd779b04d97b80e5111c6d48da73ae24',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/d85ea276fc9c6626266210a14ec356b9.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4ac277a19f4d3c8ee09646741b416cc',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/dff5319f0e3f98f5fda70bf9bf56f5f9.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97fdb8eb57005e989c6f0276888ada21',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/64d848453f2abbc613cd5473077f8609.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c13170939d650d587e576ad29bc4fae8',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/839a774fbf18d722de102dc9d9068321.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd581e0d2a108c22d0c0776ec61a248e9',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/0697066b03be9f156128d76a286744cb.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57048e9f8a2da47fe7e646174e84e221',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/7f5de0aa82f2039e8ecd787ed4b4908c.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af4d4786f61ed096112f92902bd4a900',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/b308c69c73a7fa6cae8d121a100c4da4.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5252dc37e61019bb0d1a0814444ed525',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/d198311728218dc18356203c520b40ed.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '830c5500f816c94c2f7a6efcfb4293a4',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/6e8b87f1cb6b6dcdf6b73f07546de76a.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '278857b4e1bf8856f88c1bf8ff055a3f',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/6401bbd0df633c799bc7a44644938116.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b36c999e0409596b6d7d0626603bfcc0',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/89c41a5352203dda29c630b3798bbeb9.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7305c19af58d3614602aeaf1b9814578',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/249259e85abcf477bdb39489e7953ddb.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7c8f1d3c95d1e72182bc966be56e850',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/79236d322a2ccf53c03cf226ef93d634.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3cbdf125248c4d014b153987bf781cbc',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/73c0d14fe6602c6191a69c8b1eba0837.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3905068db35eedc2a25ef317d142cc42',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/82b9bccb5e4344c58974495feb26962c.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a073ce3f1e1d9cf5cca9908bf4bc4fca',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/ddf79f46e70452c578e76dbeea8b81b4.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c39eb30aabeac0037cd1e327bd2b02d',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/30659c7372d7cdca9c500ddb24a34f76.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6caf4b91618f9154f907236c6dc486e',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/50df500a63272ac74e97f792776e5c5d.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ff688aa6cf388783da1b65852069b81',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/4d87fec4c8dcefc0ad4967586ce42f6a.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '047a8dee552eac05c13f6e3f67968961',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/e17ff585e7f66c0f8437b36fa0f13eab.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c02bbd666b3f91e661521b1df3594297',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/4c972199066f0025f6fc8dc78a5cd715.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c803b1562bedc3a9ab6487354c074ff',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/40a163f9fca393d82e6913abf6d841ec.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ad6d2f687b8ba27fdb4d120ba802cb6',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/f8e895bd228d551535a3d7786452b6ce.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b13fffe215e76d1c613ff50e32a0b96a',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/1c52127c5828569c8b410de4f221d5ae.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '435c5aca22dc3fccb146e17abc286d9f',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/3173d58d0aa1d8984fc8ecc36a1e3981.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f03537adf929328770c4d691cc6bad0c',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/214f31ad6f285d1dd38adaf07f514440.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e89239ad90cfdbc9940f2cd1463c2d1',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/8db59852e32a4e77686790ce0b11aa47.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dfab264b25e66c10bb1493036acd228',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/4d1b27190a72ee1d186701f91a8ffb9e.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '593e1df50958fd1439670bb648413c2b',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/74eec1de28717cb10254e478ba25cd2f.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc60f9e639b0aa4a5375d5c3509d646a',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/217ad9fc4d47e492a9585cbf7dda9299.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f289c4d13701c37f50d78b148b23e22',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/55fb9642cc134809b2a91873691ff1b5.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af91529ee124407f081bebe99c10ca90',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/f28b83df03db3c4c72cb49fa4afde71e.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1240b96ea19b327d9eb90b4b9e9bfef8',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/2bc116829db8d94fdc7025262a44c941.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4609124f38e3bc18a5de0aaf8979f6fb',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/9a115c669a09cbaa786a82e974e5ee33.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ffa97ca7dbef1e89c5a2bb94ec9fc7b',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/117c06f75912daf12632db7a1cd5e019.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8190d0feab827b86593a998e1b8d299e',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/2d00d33edcd23cb6825cebeab1da3abc.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '199a129bfe5968758b9148bdf2feafdb',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/63e452024789c532770018b62dcd17f5.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e33a17b94af3f30a99ccd1155b9336e',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/5c9d1065e5db3f5b952cbb7e4deb9d65.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '334fce4e59d73e7c5c0e99efd5e58a12',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/de662ce72eafef50ebd7c43b7ff26df4.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea730b13e143ee3c9808ad1c01e7fbf8',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/b99b59366497d0a330be51947fa35359.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82720c2519edfcdc1df1b1d3e696d1b9',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/d6f7c463fac8168e1d948c07f7bfe856.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5931c11ea53ae9e2d0a9af7f46e81bad',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/7ee29955ac9a7f606ba7b35dbb47ebe5.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '067e30b748d2242aa3b2a3868f6bcc8e',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/040a22bc5b789881ea5fef1224697e63.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14c4ee6dbe0b820dedc2967a1d036865',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/0a8517ada3e66aae4a7714d4e92962a7.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '346a60bd2baae498820d954002b60416',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/1c57c6a13c90286fc436791cee4be24c.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1109d889e418a5e782c4c683afa7180b',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/778902f20a129e6876d2876b5bbbd671.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '625934c670849bf86d3b1740155578a6',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/e071d612ed6a7397610783bc3be09d80.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90a85d1ae12be0c83be0f30822e9edf9',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/a6c63bd4190c9f8dc589580e4d11ca68.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0448539ca737f570ec65aa3beb39c615',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/8cecb4cd68327dff240ac9be6b7f0b70.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '433451b2f60517d29fe15033fdcd8d81',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/85fc96df560f5e9baa5a411369b299ed.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e24d3d749f1d9e08a2dc96456b2981c1',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/9cc0cdb47a133f324db300d250139935.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc6ed18211387d8539f14621da3af479',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/8871b25d404981eec0529c679d6a9d83.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a685516fa27b0d72259f5eee07c6b76c',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/51a5fd4b58a7ed12e7cc76e902b3b62d.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23bad15507912d454613b3dbcf44972c',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/63b723b32613012953d080a99fb22a5a.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eea090e631a4b804d3bd6a827ccb9941',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/7e12eba23f45de88905c0bc5c0f7e01c.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30264cc649df03e46957563a45ba6e12',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/f3e757a52b8523f89bc570b6c04138a1.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc3abd9139236f2e07f57cff952c7296',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/6665ac927f5c27c1d8f8b406579aa3f3.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'beadbae7415deeedbf9c3ce165c7f284',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/1abee09cda952f1c6f47253c89767a1e.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '550cb43b931bef94ab7acdd7555da823',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/d278b692cf2fe4afc995d8aa3144cda0.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d4950defc6984468c76088a53a5cfd7',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/0208a8fc458f992a2f747f851b22ce12.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b025395b1cb9a3cb2077a5c8f548052f',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/930dfb864353424697fd5e18a6d9c979.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10a8b508baff00de347fb7560d4e2284',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/14ff727c271724e6c806210b408e5a78.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '392d1f0316ec318d3f6df9fb2a90cb4a',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/dda921101a8b81f366ed933c87d5eeb2.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1bd9878187ea6bce008fb95af1221fb',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/a85349ce5e249438028bd3fa5066e6dc.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0077f91c892386771afac37efa05e0c',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/b29e192c19ee95742b8423f6c1432c67.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc0d88e89b991c266d9cb1a091bb890f',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/a30af3aee9d023d80d73a6aaea3817d0.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '132c48cca09f9fb9bf21fa58363ce253',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/2861da442c2b6c77145a6c01ddf3cf2f.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca0ed07285ccb6379f68a6fdc599c119',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/9ac807c02e06957b4f42f19a386a24ed.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea2773b373ff132c57b8bd3c456fe85d',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/fd46afe825766c8f0c518df40f7aad82.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d7ae4375c061662d6a21430422d4e43',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/b416d6d8578fc805becb33ada435f9e4.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2284387694bf24ff860911272fd7983a',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/dfe8c62582b593c9120f3acf9d183e2b.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a382cbe720ee43607b0d2faca3e2ff9',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/96bfe22be8276f4d5efff5a9ff34de9d.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e600703c761781362e3e640372f76748',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/4213269856a3db8d1e2361e0c6bb5ee7.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f09e321a3a19de4be75675e3e12b10ae',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/e8f6878bd5dfb47f743a197ceabf4bd2.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68058fb9f7c21e40c0468af1f8e6abc7',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/89ada51e26ae927df4f847db704468db.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9dcbfa824ab7ab7882b55ecf4302c24b',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/fd6d446e47f247a970699443327afb06.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0eff928bbaefd9343989c0d0d7789aeb',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/7b4ca012c45e4eced9bdcb5c1067adda.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91c1a55fea9586754603a65a7aa16ec5',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/c70cd3844167f1b0951476c3a637ab94.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21dcb3f95e3d46adfb21e28d9b01740a',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/e701fa98e3151a38efec6b3f121351a1.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'acff78a65dbfaa7ff03b9201361f1954',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/6ebd1b6b89f67536af6dcfd3600982e9.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18a796c1501a1d6869f57a41b65d0bdc',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/dc14f2b0575732c9ce3d8247e7798c59.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b609fff7faa815b34bf95133ed2b64e',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/94fdd91886be2cadd913d3a3c37d6bdf.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cb42e86a1a39fd459ad8a25b0c82ce3',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/bf38df2536dbb8d6dc5fa9c7b848ffbb.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0afe0d2e28cff55fdafd6982cc71ae8b',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/e86a3df55672b7320c5926f68724bad4.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6798986b03b159c14c31ace641b207f5',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/c223fa194dc97320986022041e5cfb8f.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00c3ef9d180f05965c4b3344834f188d',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/890a2f1189a9080b68286db99e179c56.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '427448a7309e37f6765690a11ee959ad',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/d02c6b0c070c6bc9268d3722a69cf8c4.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70125a13d5f7c073dfb5dac6f0063b34',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/38b6644a134aa6711b08d5b4342a5c32.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '787a4097dcaa4add28c23eea632cbaea',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/1febb621b6cb0128dd910dac35f092e7.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8929cebde346d59c4f6648f9a1decd3f',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/acd76afce578621651b1938f6acfe9ff.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2b97c8b749f4dbc17799fdf1804cdc9',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/674ed5f271fb17a6bda05144af0fcb12.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21e445a35c6d1f4a185b386fbba6efe9',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/b1c01d92f81bca7c327ca1bdbbf356c1.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e2b4cc8fe4a897902772457b80bf150',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/aa99c7a2a033a6f2efbaa47d695c3e34.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd98a3a8b379f5328eee5bf8d2b61b2f',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/f57e6c33f66de20d80c6eeddcdb1039d.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8fb453b9e98447c923779b6e5bac194',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/59e3eb7f6de54e869805c31334cd0507.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '987a6b0d4e41264896fda1b6e1a237e0',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/3fb854bcd118391ab490c2b5ad9c900a.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29e08ee8dc9b7b358545fea35f1775fc',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/49d8fb12e8c9339d79d226b1e86b8ccd.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46f20c4da59a11d40140b6b5b4d3bd97',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/c0cd10ac997a3f9ce3e1695f4e05715e.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61c0b0463afc568ebcc6bc5278aba5aa',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/c795a8bf7d621d8188c2ae495db72cf3.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7301c46bc95f450985c044620ad2552',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/7aff96a57590c42dc653ae64a1d935ff.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6439c4ce1fc2955be52b5d32b760b3e4',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/ef2fdf8215f6efb70d48a3630d1535e3.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcb65260de2b3db41f59cbed708aebc4',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/643dc91304a9f700c52514ea19683c35.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecc52896d1fb684461833f862e7bc39d',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/e0987e5a77167b376c421c06add64037.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd469a87efcb267c3025ec410e8d3fbd2',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/ea46a8f336cc6ee48a2d0bf84fa3f3ca.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d96edbdb70144a9f52e53f50daa46a7',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/4e78d677178f6a7346f79200efc68bda.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '631c6ae08fc47e76d30db8ae91e3f797',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/1b8dac06c82d55ed6b85663ee3b35803.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1467cc6ca6f65590d5c05a8f88ff7248',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/6011b61600975c34d8c05a73900d34ab.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca7dff6b6ff9d1646a8669425b3e3772',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/d536f6e726e1131a204b2d3e9dae17d1.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bf7369064f73f234b009b6faa7f8e7d',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/f0560662efb29f6506501aa57bb5843d.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8faa3fb4d122ac660cd0882f66b63765',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/c82a6bfb0202158b28b40d9e4dfa7c8e.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd594e72a58183f1714edf5b1cb8cee4d',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/8d7e45b595aed45e78bbc00fec9ba1ab.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cb67d9d67075a858af897e8e815e23b',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/8ebfdeb8273ca8e9163ad5e3266a7fe5.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '947b07f9f2b7f0d3b3e288c0c94bd06b',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/d30ec80b4d72d07fd2ad49e352dd2b14.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9a43a1c499cc9d16a290cb3fa8f717f',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/96c26aa63e16019afdf1dc1e31f028db.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f24468f4426deceb4758b58c09d69f71',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/fdfea5b9fa981e05df6a3fd71db9df91.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c81534ed3ca3f941731a0fda3165a517',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/cd085b8a157a42850635e5e607c052c2.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7de8db35b8a7786decaf2466ca381b65',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/9c2643d0c5fd4f1e2c1aeca22452e5d7.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8953e5d02989cbcb4d2bfc59a8c7f533',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/7d678f3372509fd1ec1bce203871b13b.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6adc62b3615550e3833defc0d7b4752d',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/0da5bc4a467bdc395cb64129626f1e9c.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc9835d134694e884665501dd0582b88',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/3b3bc1acec7afd916c39fd8b48f934d8.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9ac39aea2f50b647b7b3eb18e712450',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/b1cb7bbebb31d1ea8cfd08d1dbd85870.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdd53db69fab7e797fd195f6b5f495dc',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/0e3e243aa786d63c95a5bbe16549844f.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7df36012a7de80f564ea256acb21ae7',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/ac502d7be0171812f991e5ea48710599.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '639b5f7dda74152c831446758446a8d8',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/e075ea26fb751f5c0bbfb82b3e24070e.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98364a4e93b943c6fbdd0c08ea46f88b',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/781254ad43059fe1415e508d77018756.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f15dd7b3af4381a35457121c9f34404',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/5060072a24fe8acbe6c6ba4007fb37bb.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1bc9e09fa6f77b5b543c7df17388582',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/78df5b44950469a106f7723b9af04f94.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff2670508a61fdca68aba55417e6d8dc',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/f5cb8bab62030a03855c32b6e79489cf.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c5480594f665fdf82f08b7a5116c057',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/8e5c68a6695f0c10b4bfddc8a26cf9f7.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3279a67ff9c462d761b82ae7625970f',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/2cd3838f301130bd161d2735d8f4c2a2.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a646433370a7108d4989978e896e2585',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/c71285aca53af57c1c6efc20c940718c.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2096ebfa528443bd290e89082fe2e8f9',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/33f5dfa6d767fe5f09666c67d5bcd327.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ff8679b89c8f0762ca71cd7106b0006',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/8712d0986f506b0e0f23c22c40cc0d52.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9df5449f4058ec17074b0cedaa23ce5',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/fc47cc49ffc90bb31b643eaf1168d381.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c325e5b630aa4c9e149104a9b83eeccb',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/e1897d37563fc9ca6dddcbeac5c239eb.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db78f646c9600d45a365169f74d5a042',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/5fc40b8f26fda016d1b0434543aac0a0.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f2dc9dbd66a118793b6c2c8504d0a78',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/8373836e8c2657d4f67f8f6b179f3469.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92d56a9135fe32834946a3b469bc8e93',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/3915cd30a1004acd3d604b74d0b3060e.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84c42561797de00e2540cd55ba744c15',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/44d5b69d29c6f478d005f7e2c6be1612.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d77d17418848fe6024ffc85c9e53fca',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/de441ebd218b0577af308cc328357d8a.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08bc337487b8bb1dee827a8105a1fc0d',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/74c7874e8df2f7267d29586bba2a2817.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c77828c3a56ee15fc20251771b8ed95f',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/883632eafa5f355806a00bb49d40702d.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b27e760d4daac4f5b5aa362a45d1d88d',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/64d28c7c20bdd0082920a1ca0741d14b.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f116d73b076747184ceedc0024a5844',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/a0a990bbbbc94866b04cc7f08f40b5b9.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8f73d901aab3f041636167cbda7671a',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/f816d5f3440fafe8a845c527a283d642.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a29099dcf979b7f8aaa3de78ca39b6b',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/29c7dbba8b8f47ed861caf07214768d6.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c97ed27e9db27870d201bb3957dc852',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/9c2a8c7ba080a508a18918efa2be7846.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd76c5712117076ad535e0568f3c43dda',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/deb8be2a81a82acb62cdd85c2f01e18d.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '109df06e8992c82e7ca15f784759d6a5',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/348aa058e287ac17a2efc5dedc65c9ea.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8204385acd202a28ba45c9a5147bec4',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/39d132bac0750ad64da6c52b92311f7b.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab2577ffdc64eacf37576cc66df9a87a',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/d0f651264a8e6c25b98c3e2d669a9818.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20873ab61dd5b8e7e78dfa8a1e24742f',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/8a10a3d44b7647554c07716ad7188abf.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba10c643800e8103c926856bfa32b5f9',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/aa248518fb4372ebd67b982a25f46de7.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8f34502ac49a267691f016ddfe3cf60',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/bae90b6cf2e5f28c2390788a35e39300.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21ce4b2467ba8b0a38ca6026e90d1716',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/4e3e62b121136cc08e4d5dda854e2a41.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb92e5e0e2d5c347423311c316d8371d',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/9abd37086e02645085c3c8586cf3b84a.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8241807452168ec49cc94a2574e49264',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/ac79679a9531665f56ad3583f63b4bff.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef0a6fb9d4d9c50c54d279e519b000df',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/be807628dc1ea3b9def52649c43872ae.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77f6598859a74bbc1f14a765e28431be',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/0a41fe343d640fdc4ffb609daa279106.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06a8279b5c6de1bca0aa2478a2a478e1',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/20ba1326ed67415f68bd54637abf4d4a.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72c5dc2da3f0448db136be6720333b38',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/bd84fe3b74ec19f687707c28efc218cc.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c8189730b562c3cdf9e3e4f26b4a47b',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/2e2213717ba5ade2da875fe8c291daa7.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd13358da45813312dfc253b0a6654bd',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/2e5bbbd2d1c4070da173b0d23bf587c4.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '260e05e717dab2a5d6d96ee377e8b8b0',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/eece58992493cd40a46cd423fd23f3ca.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b6ca3e66329529ee1066d4d323a7e7d',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/a4452afb1e1f032693462518c428046a.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17df0ddb364c1f1320eb6a58d801ec1d',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/e3e651e15d322f438aa9ff07e45af969.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2328913a068bf4dad2b18e0205b25e64',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/0231f957e92e6a5b005a9d70cebd3405.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75df10e38c7a98b855d48a39554241c6',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/eb12cef60b2eaa7bd1c0fbb86b63089f.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cec4115f6526486624ba5c3f2ca37ae1',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/e56c3d74486f0738c4c638f70c702d77.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d0c241f2adddc275480dfd903843859',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/b09f6c12b1b555e7891de427a9f469ba.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '654fd4cd1450add8531c27394a802e8d',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/3346426afb0ddefbede0c24a3691dd6c.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3675cbaa8628c8300b51d3b81c5e9107',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/53139e27548b12527ac01ffbde670db0.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '513566d0a6d6aa60e467cccf0cd38137',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/722219d304f3b459430769ff8a611ab4.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d32aea385127ee316ecf5c4308bdafe',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/73b4d49137fd0c9d46b59fcc0f6869e6.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7277da7eb96c26b4df966e9ff312b8ff',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/1517d7b7d10bdf62d49bcea9617675ed.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97cdc8a34b1baa5c2ad7c311ffdcf6ae',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/464579d060b293965240dfc57d90fc0e.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2824904257d89275fbca6ae126dcdeb',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/2c55ccfacd61d87a8f7338ba24fe8d33.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af198456855a70eed76bad4bcaf406b6',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/b4a69125844fa1e6df87ea215e7ea199.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '500229f15ecbbe6922072b71dc73a36c',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/6a1affa4660d56bbad04c02d759f7c33.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9807967576b29a14f013c94d1d152fcd',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/a1179c9d38ec1ae74949b2c695f6c9a7.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36ab30c4de54aabfd16da5133377859e',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/c518b919cbadf18d4daa13a240b5c4f2.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59a533e52f55275d049c82020bbaffd7',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/30cac1f6616f0db00449f5aff849acaa.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3287ad0e49dafa11e317be41f15bd612',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/0dcfce8706055c5a7d69faa87c65e656.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92960998ee27444f28d87522230fb621',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/8d58d68173c82f2b550e2dc0fdb3ad21.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58e3b2c36f0523555153becdd8d3f0ce',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/3e5236d47dd4abb32121fb35f6d02c83.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8151ca0a24f28937d6ab5734202496a9',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/2a8a395b887447f7fb4e55d4f7dfb9bd.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ca0e8d3ed74e3859aa1f95a8a888bae',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/81c1e049c7f60909f9e5fa66f621d5f9.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e62b49400442f8e67b739ffe05b41e8f',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/1cda4c866d58dc78e99d85dfa90ed4d5.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7132bdea0bab9ba92447a33e6729549f',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/ed4eceffef8f9983bae55c0d2112cb07.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d1841a94e8c027c8217266c0be800af',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/7a561fdf66f7f1a5affb287e0aecff2f.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2840e9c9b730a8188c4cd1748b24a958',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/5a6349da8823fbb72c6ca99439c3174b.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b36fa5d18ee8c9516e6645550c57b044',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/e3a168184c1463b8206694b39ba4afb9.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1737de20c30629e5e5081a5f503ed562',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/4539f88d0cf6216d1cec2ee4545f720b.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf049e306ae986479414e4418030ec67',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/30932dbe8e05687599e27addd6003053.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02d9e157e2ac33c72a4b4285f17b6469',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/feda845da34f8b11dee358eb3d0b9d6e.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbf10d4c6d164daac83d78d64a473066',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/ceb7a274da64857a978be8d486a09e73.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '919dd84a38bef5d8ca3c6479395454f4',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/01e36ac7d2bde130fde8d148d12528a7.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a3b210e758fd812f34f06cbefc03b0a',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/28c593a26b0112acf3504823ef1657b7.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4112a9bfd8111039c12a21c7646f1d1',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/8780102373bab05ea0fc18b04e947ebe.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e815cbd6a5d7800df5972541f70e5468',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/0a4d1b77feca7acedccf2eed6369c93f.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cff90fbcaae4ee3d201bb259efb2830f',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/a114e7bc0adb62b58e0e1298853b4f59.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '727f8f071bb4838bc0b5d50bebb231f6',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/3219bb654218a26229700c4782429e40.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ea7bbae5fe56de76584fdc9d6f03d08',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/e81b82d67edd79f7999632a267be151e.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35d8275aeffb4adbcdddb35b8e5ac3fd',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/0f558e14982a2cc58298f9818ecfdbfe.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70bc6df6213ed42b36d7143116d5fafe',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/b8804f5405465055ca34b7ce60fdc567.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7191c4ee61124a7cf038e82aab3d044',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/0aa5170a3c1d2807f620bdc350ea3ccd.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45b16a71dc11167c5796fe576290250f',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/7c6cdcfd8ab55572510719ea740400f9.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0390fe61fd350f1ecc2c2aab8a5ac6db',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/bca9d6a1cca06507761e462aaf80f762.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '958631d2e848992b52f95091e1b6c5b2',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/14e23c4e7fe7fe7e496fb3a441f871da.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '678fa3022b877d4de6e7fa9e5f279a40',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/bd6c8c6a484938854eba7098c99737ec.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2b54850227da2651faad615242c15f3',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/41987d87fa6e23fda8388705fed4b1bc.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d65bd9c932c2dceadc5f7830e60171d',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/74174e5445f1a661669efee857233b42.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '344c7249a144ff891648f3b952b31447',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/9229251526fcd1b9ab2f99151fd7882d.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f862c4965f7f3a710ae319ee56675fc',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/f92aa32522d7325bfe35bb9b8571ca3f.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da5c7a9d86883ba58a2171a325bfcd34',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/dd51d807a95a0f4b93b4691aec9dcd7e.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '073fba4f428bef393753efe86d9a7f6e',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/9116fcc7a5c3e5ed5d51fd12236da547.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '430a9e4538b634f85627e484d193a01a',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/47d0a1417d306ebd12f67a9c047461b3.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8db476e5132e8e77e4a734ccfe274848',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/f63b1fb639031d6e4124d9dc6ff84e56.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '252325bab827d294596ce385f7a02daa',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/921e8de857d48f0a460e619ba2159f17.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '548fa9a3433fbdae8e04486c92c2a2ea',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/9c2ef81c077ef214d03e5881d3c3e329.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1e36054f64624b9fae85248767c7d6c',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/b332c7e4c0da9b785c7ac6ae5630d01a.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b9862a3d1d3859bb9b11b3c08e296fb',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/b157dce4c3bf5376aeff1c911ccf6b9f.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd78557fe7fc7834ccc4939aa57e92bfd',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/736224da10eb3368b4fad92379e63540.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7df89a0990720cb7558856424e1897d9',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/4fd912242e28ef0b7b4d8331d93c1f45.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe0b576a88dcc89a6eccf21ac6af5364',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/a08f2154adecca84f7201911729e1375.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96a4dec8f9b1ac7d01fb099d0e99d8b6',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/3585e7afb102f954ac93fe89f0f18cee.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d380559af72047432b86958e83fad91',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/d33e074477aad64709f25f020b1e132f.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ba7add0db961414ee524fceb1471de0',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/a43cb701246cb3672f734be4475e9710.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81b99dd1da8518428aedbc0b3e3ddfb2',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/78c180bd422983501b5f9da887e4a01d.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fa3816162f75c0102318df44f4e1c2a',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/16f6edc05133845ab20abd8af8b55538.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffc96de44ea881db21b542bdeeef5360',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/af4941ec65d5effa5abbac2371e56609.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '509979293aacae098dca83b48baf3aa8',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/945c3f9067ef97d3c6c70edbef41a874.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e45555013b2fbcdc8c9a739260cafda',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/81cd620fa38a58acb594842b53faa07c.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc38f45d762c5d90c8e3549bcf75bf6d',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/5e89c9a6775ee8ac4218e6ca8149c1f0.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c34f03f60f4a2e7cedb83718b59f7750',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/5afd805aba23523de4bf9010ff7df403.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3839ba0677a567b0c53f536527683794',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/1ebc906e373f57307788aaa1195e1f26.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e544a8789c45ab02185b9f1e59983d74',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/891c9dcb451f78aea6553f6b72a9f41c.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6395a2b829d9478ca87c7d210b08f8f0',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/2f05d799fa5a7a5cc54666409c784cf9.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e11f319ac46a3c38ab28c5c5ee1ee680',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/e3fc8f19a12a5aeb796b9f4ca48e0781.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec4e9934783b3d56e0a03644a85ea4d1',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/4e2efc68199b88b767f3930fb2dc72a8.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'f27904d546546af338fd24e7cad49728',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/e58b6c09bb28bc031555e6bbed9c3a3d.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '02f8d924fe531816d702c0bfe6a8b695',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/a1a0388b8db1d1dcde45cb875f94b4bf.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'cf0cab9a740e390a74504adacb4b5833',
      'native_key' => 1,
      'filename' => 'modUserGroup/a944306a8b44be8646cd55edf1c0cdb6.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'aaa7e37322979667f495cd897344da63',
      'native_key' => 1,
      'filename' => 'modDashboard/08dedb60eb53a3499492cad9e779a24b.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '2d3421c927f3a325d54e1be7d0809a28',
      'native_key' => 1,
      'filename' => 'modMediaSource/89a13a6f7713772daae029bbf761e7dd.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'c81b2783356c2540839cd01694fcdd48',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/681fdedcb5c31a44c1f52e486a6b588d.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '2ea8d18578fcf60f6f516a7d408b80b9',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/fb34cefd0399fc4b74d022c94ff3aec4.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'ca63853db5261c612660d5038433b325',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/d16bfcdad2a07eba1de35fa07d5b8d03.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'eada8a4fa2ebbb3619a96c4545399dc9',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/17714b17761f9226a25e2b66873a879a.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '65e5da6a96c4040183cfddba23e5ce66',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/fea10cb060582d5de84089ed541a1621.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'a1984771587b04f0cd31faa955c1f385',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/f736139e3bc2fd04ec599a578fd3d47f.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '1131e66c854072b59cecade76b16d8cf',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/0d8551fbd3f24ff6864d12927e3f8def.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '0d136555a0491aee02a1880716d8cee5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/3864fbbd7334f7f941bc287fe4653363.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '9f42745f0e029d33c8e6a2187c7a00c5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/00c3a455fbcbbc690162b1bd4f993922.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '46808b926ca9a134c210cd366c44f790',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/98ace4f004507cfe1addd17cda9221c8.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'c0f16b03bb0d2ea903f01b18f9a7cd4d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/462206ee99769369a7ee0d517769a9ab.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'addd23aa399581f0c145aa0265cfcc2a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/682c13b05cd4daf201bff62530151674.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'c654f89c39ee213ea3f5f69af69adf7b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/fd427746ded02490bdc9cf85c514dd8d.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'c1e43a4e5b4c514041d3312f3389cbba',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/60b978e51b03fe5e7939fc6ed109aa7c.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '88d66fa9be19db6cf11acde0bcdf33e8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/0163d47a9e9932f07e91c783f51de928.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'f71cdd1a53f8947d50a2cbb02a7c2f8c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f32dfa25e9be3e86cf05e08ba81f2bc0.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd193488644f74baa25070264cd7cb468',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/4ea9dd3b57d15ca6ab69202bb94b0f98.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'dfcaeb6b17b45ad012ddfd2ab3854339',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/785bfab4ded6eb2001ca7428bbeb1b38.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '46f31095dbffacd6dc98b5e7822a7852',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8c9693e6dd87549ed1518e7cb1c6b784.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5f763ee9f3b313cf8c86521baa6ed8a5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c5ae7479ad14571bc0b7207c6aaad4b3.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3591d857d959c5353540c90333e0cc5d',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/81c131db00a2f3420e7d2d024a0d4c39.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8d4712ff49d0cd178acda0058a2a1c8f',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/c2cd813a4b4934a00a7fcf0e97c20807.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a047fb90e2bf1c12a32f5d14963aa353',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/2aae017cf26bc3012e0898dace077b8d.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3f18129310d01491c22881f39ea5d1cb',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/ff82d2c33c0c24288e7cdb68d0dc34cc.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1f48448ef3ea9e058c277fa92b139406',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/9eb08fc42a8df448b3aae182b3203c50.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd45295318c4c2bc3723959d19c010dab',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/16d4a40529b54f71e6480461061a9250.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '849bde2e39db5490d29f8eb379da58ad',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/74b88eea7ac6726e91ce40ae51e73cc5.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0e0d892465a38ce5ff21f1ef025b0576',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/ce31fa35cdb423de7b5f7775dcf7689a.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e907475fb6dd84c54445557c57ce9d03',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/1ee57b5efcefb3d1a8b77fbb94585874.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8277c36ec4b3ba19efb6501938520fcd',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/19898d935558514bcff517d33f13db10.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd002bc279326e2ed5354b17798e025f8',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/ab9c2e85ad6542e5e2faee6b40d5048e.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4e7526b6f8f7f61178260c5a9e52a92e',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/54369d17e93a695cb79d5c8017d53da2.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '38dfd1040f4429c6a10d33f1b54b76cc',
      'native_key' => 'web',
      'filename' => 'modContext/ee8371d134483fff7937d51391efe348.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'c2a7f9458f1050779d0f45d1fe453424',
      'native_key' => 'mgr',
      'filename' => 'modContext/e1605274c80a3b04714ebfb596516855.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a4f087a23cc44b0ed96a039698edaf15',
      'native_key' => 'a4f087a23cc44b0ed96a039698edaf15',
      'filename' => 'xPDOFileVehicle/ba126d573d69f603cb9e9fff31de270c.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '5a60e21368a93e2ecc9e02ba1b131e87',
      'native_key' => '5a60e21368a93e2ecc9e02ba1b131e87',
      'filename' => 'xPDOFileVehicle/238dc0dfc087f73caca6610efa9711d2.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7b5377d24db7a18a930f899e8142df0e',
      'native_key' => '7b5377d24db7a18a930f899e8142df0e',
      'filename' => 'xPDOFileVehicle/02f2376dfa94726d280ea70aab3c84a3.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ba06a6d2e83dec678af2f2976f62530c',
      'native_key' => 'ba06a6d2e83dec678af2f2976f62530c',
      'filename' => 'xPDOFileVehicle/cbab3ef3f0a5e998264a1903ee8e5e49.vehicle',
    ),
  ),
);